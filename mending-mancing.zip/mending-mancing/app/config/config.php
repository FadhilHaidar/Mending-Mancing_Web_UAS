<?php
// URL Utama (Sesuaikan dengan nama foldermu)
define('BASEURL', 'http://localhost/mending-mancing/public');

// Database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_mending_mancing');